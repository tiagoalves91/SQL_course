# ex 1 when you know is fixed length;

# ex 2 - item_name VARCHAR(100),  price DECIMAL (10,3), quantity  INT)

# ex 3 - datetime is a type , timestamp is a FUNCTION

# ex 4 - SELECT NOW();

# ex - 5 SELECT CURRENT_DATE

# EX6- SELECT DAYOFWEEK(NOW())

# SELECT DAYNAME(NOW())


# ex 7 - SELECT REPLACE (NOW(),'-', '/');

# ex8 SELECT NOW('%M');

# ex-9 CREATE TABLE tweets (
#     content VARCHAR(100),
#     username VARCHAR(20),
#     createAt TIMESTAMP DEFAULT NOW()
# );
