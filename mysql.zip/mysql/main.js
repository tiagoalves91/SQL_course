function main(){
	console.log("Hello goorm!");
}

main();